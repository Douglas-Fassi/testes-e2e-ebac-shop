class NomeClasse {

    nomeMetodo(parametros ){
        //ações do método
    }

}

export default new NomeClasse()